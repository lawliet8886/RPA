# CI (GitHub Actions) – Build APK Debug

Este repositório já vem com um workflow em `.github/workflows/android-debug-apk.yml`.

Como usar:
1. Suba este projeto para o GitHub.
2. Vá em **Actions** → **Android Debug APK (CI)**.
3. Clique em **Run workflow** (ou só faça um push na branch main).

No final do build, em **Artifacts** você verá:
- **debug-apk** → o APK debug
- **build-logs-and-reports** → `gradle-build.log` + relatórios (mesmo quando dá erro)
